from datetime import datetime, timedelta
import pytz
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.forms import modelformset_factory
from .forms import *
from .models import CompStream
from django.shortcuts import render, redirect, get_object_or_404


@login_required
#Mypage view function for ComponentForm
def componentview(request):
    compIdVal = ''
    form = ComponentForm(request.POST)
    print(form)
    componentVal = form.cleaned_data.get('componentsList')
    print(componentVal)
    if componentVal != None:
        compIdVal = componentVal[0]
    print(compIdVal)
    details = StreamDetail.objects.filter(comp_id_id = compIdVal)
    print(details)

    #For email
    contactform = ContactForm(request.POST)
    print(contactform)

    contactform = AuthUser(request.POST)
    contactform = AuthUser.objects.all()

    edit_form = CompStream(request.POST)
    edit_form = CompStream.objects.all()

    return render(request, 'mypage.html', locals())

@login_required
def streamsview(request):
    compId = request.GET.get('comp_id', None)
    print(compId)
    data = {
        'comp_info': serializers.serialize("json", StreamDetail.objects.filter(comp_id=compId))
    }
    print ('----------------------------')
    print ('JSON Format data',data)
    print ('----------------------------')
    return JsonResponse(data)

@login_required
def save(request):
    c_form = ContactForm(request.POST)

    if c_form.is_valid():
        component = request.POST.get('componentsList', '')
        streams = request.POST.get('model', '')
        email = ''
        for key in request.POST:
            if 'email' in key:
                email = email+request.POST[key]+','

        comp_obj = CompStream(component=component, streams=streams, email=email)
        comp_obj.save()

        return redirect('/mypage')
    else:
        c_form = ContactForm()

    return render(request, 'mypage.html', {'c_form': c_form, })

@login_required
def updateInformation(request, id=None):
    print id
    edit_form = EditForm(id)
    context = {
        "title":"Edit form",
        "form":edit_form,
    }
    return render(request, "edit_post.html", context)


def delete(request, new_id):
    new_to_delete = get_object_or_404(CompStream, id=new_id)

    if request.method == 'POST':
        del_form = CompStream(request.POST, instance=new_to_delete)

        if del_form.is_valid(): # checks CSRF
            new_to_delete.delete()
            return redirect("/") # wherever to go after deleting
    else:
        del_form = CompStream(instance=new_to_delete)

    return render(request, 'mypage.html', {'del_form': del_form, })

def updateform(request, id=None):
    updateformset = modelformset_factory(CompStream, fields=('component','streams','email'))
    data = request.POST or None
    formset = updateformset(data=data, queryset=CompStream.objects.filter(id=id))
    print(formset)
    for form in formset:
        form.fields['streams'].queryset = StreamDetail.objects.filter(id=id)

    return render(request, 'edit_post.html',{'formset':formset})







def feed(request, uid=FeedDetail.uid):
    uids = CompStream.objects.values_list('streams', 'email')
    stream_array= []
    generic_array = []

    for uid in uids:
        uid_form = CompStream(request.GET)
        uid_form = CompStream.objects.all()
        feed_form = FeedForm(request.POST)
        query_results = list()

        print ('current date time is', datetime.now())
        print ('1 Day ago ',datetime.now() + timedelta(days=-1))

        #Data for 1,7,15 and 21 days
        feed_s = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-1)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
        feed_s7 = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-7)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
        feed_s15 = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-15)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
        feed_s21 = FeedDetail.objects.filter(uid = uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-21)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')

        #List for storing the values
        val_list_21 = []
        val_list_7 = []
        val_list_15 = []

        for feeds in feed_s7:
            val_list_7.append(feeds[1])

        for feeds in feed_s21:
            val_list_21.append(feeds[1])

        for feeds in feed_s15:
            val_list_15.append(feeds[1])

        # Calculation
        if sum(val_list_7) > 0:
            val_7_Avg = (sum(val_list_7) / (len(val_list_7))) * 100
        else:
            val_7_Avg = 0

        if sum(val_list_15) > 0:
            val_15_Avg = (sum(val_list_15) / (len(val_list_15))) * 100
        else:
            val_15_Avg = 0

        if sum(val_list_21) > 0:
            val_21_Avg = (sum(val_list_21) / (len(val_list_21))) * 100
        else:
            val_21_Avg = 0

        stream_val = uid[0]

        #Append all the values to the list
        generic_array.append({'stream':stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg})

        print("------------------Printing the email ids to which this data has to be sent ------------------------------------")
        email_ids_array = uid[1].split(',')
        for email in email_ids_array:
            print ('Emails are',email)

    print("----------- Printing generic array -----------------------")
    print(generic_array)
    return render(request, 'feed.html', locals(), {'generic_array':generic_array})

def set_timezone(request):
    if request.method == 'POST':
        request.session['django_timezone'] = request.POST['timezone']
        return redirect('/')
    else:
        return render(request, 'template.html', {'timezones': pytz.common_timezones})














