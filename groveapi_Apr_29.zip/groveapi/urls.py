from django.conf.urls import url
from guardian import admin
from django.contrib import admin
from . import views

# from .views import edit_post
    # ,new_post,post_list_admin

urlpatterns = [

    #HTML Page
    url('mypage', views.componentview, name='componentview'),

    # url('admin/', admin.site.urls),

    #Streams
    url(r'^component/validate_compid', views.streamsview, name='streamsview'),

    #Emails
    url(r'save/', views.save, name='save'),

    url(r'^(?P<id>\d+)/edit_post/', views.updateInformation, name='edit_post'),

    url(r'^delete_post/', views.delete, name='delete_post'),

    url(r'feed/', views.feed, name='feed'),
]


