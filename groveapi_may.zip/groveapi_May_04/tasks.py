# from __future__ import absolute_import, unicode_literals
#
# from celery import Celery
# from celery.task.base import periodic_task
# from celery.schedules import crontab
# from .views import *
# from .forms import *
# from .models import CompStream
#
# app = Celery()
#
# @periodic_task(run_every=crontab(minute='*/30'), name='groveapi.tasks.send_mail_task')
# def send_mail_task():
#
# 	uids = CompStream.objects.values_list('streams', 'email')
# 	stream_array = []
# 	generic_array = []
#
# 	for uid in uids:
#
# 		query_results = list()
#
# 		# Calculating the data for 1,7,15 and 21 days
# 		feed_s1 = FeedDetail.objects.filter(uid=uid[0]).filter(
# 			timestamp__gte=datetime.now() + timedelta(days=-1)).filter(timestamp__lte=datetime.now()).values_list('uid',
# 		                                                                                                          'value')
# 		feed_s7 = FeedDetail.objects.filter(uid=uid[0]).filter(
# 			timestamp__gte=datetime.now() + timedelta(days=-7)).filter(timestamp__lte=datetime.now()).values_list('uid',
# 		                                                                                                          'value')
# 		feed_s15 = FeedDetail.objects.filter(uid=uid[0]).filter(
# 			timestamp__gte=datetime.now() + timedelta(days=-15)).filter(timestamp__lte=datetime.now()).values_list(
# 			'uid', 'value')
# 		feed_s21 = FeedDetail.objects.filter(uid=uid[0]).filter(
# 			timestamp__gte=datetime.now() + timedelta(days=-21)).filter(timestamp__lte=datetime.now()).values_list(
# 			'uid', 'value')
#
# 		# List for storing the values
# 		val_list_1 = []
# 		val_list_21 = []
# 		val_list_7 = []
# 		val_list_15 = []
#
# 		for feeds in feed_s1:
# 			val_list_1.append(feeds[1])
#
# 		for feeds in feed_s7:
# 			val_list_7.append(feeds[1])
#
# 		for feeds in feed_s21:
# 			val_list_21.append(feeds[1])
#
# 		for feeds in feed_s15:
# 			val_list_15.append(feeds[1])
#
# 		# Calculation
# 		if sum(val_list_1) > 0:
# 			val_1_Avg = (sum(val_list_1) / (len(val_list_1))) * 100
# 		else:
# 			val_1_Avg = 0
#
# 		if sum(val_list_7) > 0:
# 			val_7_Avg = (sum(val_list_7) / (len(val_list_7))) * 100
# 		else:
# 			val_7_Avg = 0
#
# 		if sum(val_list_15) > 0:
# 			val_15_Avg = (sum(val_list_15) / (len(val_list_15))) * 100
# 		else:
# 			val_15_Avg = 0
#
# 		if sum(val_list_21) > 0:
# 			val_21_Avg = (sum(val_list_21) / (len(val_list_21))) * 100
# 		else:
# 			val_21_Avg = 0
#
# 		stream_val = uid[0]
#
# 		# Append all the values to the list
# 		generic_array.append({'stream': stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg,
# 		                      'val_1' : val_1_Avg})
# 		local_array = []
# 		local_array.append({'stream': stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg,
# 		                    'val_1' : val_1_Avg})
#
# 		local_email_array = []
# 		email_ids_array = uid[1].split(',')
#
# 		for email in email_ids_array:
# 			local_email_array.append(email)
#
# 		send_email(local_array, local_email_array)
