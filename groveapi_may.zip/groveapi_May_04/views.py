from datetime import datetime, timedelta
from django.contrib.auth.decorators import login_required
from django.core import serializers, mail
from django.core.mail import send_mail
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden, BadHeaderError
from django.forms import modelformset_factory
from django.conf import settings
from djcelery.schedulers import info
from .forms import *
from .models import CompStream
from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import EmailMultiAlternatives,EmailMessage


@login_required
# Mypage view function for ComponentForm
def componentview(request):
	compIdVal = ''
	form = ComponentForm(request.POST)
	print(form)
	componentVal = form.cleaned_data.get('componentsList')
	print(componentVal)
	if componentVal != None:
		compIdVal = componentVal[0]
	print(compIdVal)
	details = StreamDetail.objects.filter(comp_id_id=compIdVal)
	print(details)

	# For email
	contactform = ContactForm(request.POST)
	print(contactform)

	contactform = AuthUser(request.POST)
	contactform = AuthUser.objects.all()

	edit_form = CompStream(request.POST)
	edit_form = CompStream.objects.all()

	return render(request, 'compstream_add.html', locals())


@login_required
def streamsview(request):
	compId = request.GET.get('comp_id', None)
	print(compId)
	data = {
		'comp_info': serializers.serialize("json", StreamDetail.objects.filter(comp_id=compId))
	}
	print ('----------------------------')
	print ('JSON Format data', data)
	print ('----------------------------')
	return JsonResponse(data)


@login_required
def save(request):
	print(request.POST)
	print("-----------------------------------------")
	print(request.POST.get('edit_id_val'))
	print("-----------------------------------------")
	qset = CompStream.objects.filter(id=request.POST.get('edit_id_val'))

	if qset.count() > 0 :
		email_counter = 0;
		component = request.POST.get('component', '')
		streams = request.POST.get('streams', '')
		email = ','.join(request.POST.getlist('email'))
		qset.update(component=component, streams=streams, email=email)
		return redirect('/compstream_add')
	else:
		c_form = ContactForm(request.POST)

		if c_form.is_valid():
			component = request.POST.get('componentsList', '')
			streams = request.POST.get('model', '')
			email = ''
			for key in request.POST:
				if 'email' in key:
					email = email + request.POST[key] + ','

			comp_obj = CompStream(component=component, streams=streams, email=email)
			comp_obj.save()

			return redirect('/compstream_add')
		else:
			c_form = ContactForm()

		return render(request, 'compstream_add.html', {'c_form': c_form, })


@login_required
def updateInformation(request, id=CompStream):
	print id
	edit_form = EditForm(id)

	context = {
		"title": "Edit form",
		"form" : edit_form,
		'compstream_id': id,
	}
	return render(request, "compstream_edit.html", context)

@login_required
def updateform(request, id=None):
	updateformset = modelformset_factory(CompStream, fields=('component', 'streams', 'email'))
	data = request.POST or None
	formset = updateformset(data=data, queryset=CompStream.objects.filter(id=id))
	print(formset)
	for form in formset:
		form.fields['streams'].queryset = StreamDetail.objects.filter(id=id)

	print("Printing id ",id)
	return render(request, 'compstream_edit.html', {'formset': formset, 'compstream_id':id})


@login_required
def feed(request, uid=FeedDetail.uid):
	uids = CompStream.objects.values_list('streams', 'email')
	stream_array= []
	generic_array = []

	for uid in uids:
		uid_form = CompStream(request.GET)
		uid_form = CompStream.objects.all()
		feed_form = FeedForm(request.POST)
		query_results = list()

		print ('current date time is', datetime.now())
		print ('1 Day ago ',datetime.now() + timedelta(days=-1))

		# Data for 1,7,15 and 21 days
		feed_s1 = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-1)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
		feed_s7 = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-7)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
		feed_s15 = FeedDetail.objects.filter(uid=uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-15)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')
		feed_s21 = FeedDetail.objects.filter(uid = uid[0]).filter(timestamp__gte=datetime.now() + timedelta(days=-21)).filter(timestamp__lte=datetime.now()).values_list('uid', 'value')

		# List for storing the values
		val_list_1 = []
		val_list_21 = []
		val_list_7 = []
		val_list_15 = []

		for feeds in feed_s1:
			val_list_1.append(feeds[1])

		for feeds in feed_s7:
			val_list_7.append(feeds[1])

		for feeds in feed_s21:
			val_list_21.append(feeds[1])

		for feeds in feed_s15:
			val_list_15.append(feeds[1])

			#Calculation
		if sum(val_list_1) > 0:
			val_1_Avg = (sum(val_list_1) / (len(val_list_1))) * 100
		else:
			val_1_Avg = 0

		if sum(val_list_7) > 0:
			val_7_Avg = (sum(val_list_7) / (len(val_list_7))) * 100
		else:
			val_7_Avg = 0

		if sum(val_list_15) > 0:
			val_15_Avg = (sum(val_list_15) / (len(val_list_15))) * 100
		else:
			val_15_Avg = 0

		if sum(val_list_21) > 0:
			val_21_Avg = (sum(val_list_21) / (len(val_list_21))) * 100
		else:
			val_21_Avg = 0

		stream_val = uid[0]

		# Append all the values to the list
		generic_array.append({'stream':stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg, 'val_1': val_1_Avg})
		local_array = []
		local_array.append({'stream':stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg, 'val_1': val_1_Avg})

		local_email_array = []
		email_ids_array = uid[1].split(',')

		for email in email_ids_array:
			local_email_array.append(email)

	print("----------- Printing generic array -----------------------")
	print(generic_array)
	return render(request, 'feed_details.html', locals(), {'generic_array':generic_array})


def send_email(local_array, local_email_array):
	subject = 'Feed details information'
	mail_string = '''
			<html>
			<head>
				<title> Feeds details</title>
			</head>
			<body>
				<table border='1'>
					<tbody>
						<tr style="background-color: #4CAF50; color:#ffffff">
				            <th>Stream UID</th>
				            <th>Last 1 day data Average</th>
				            <th>Last 7 days data Average</th>
				            <th>Last 15 days data Average</th>
				            <th>Last 21 days data Average</th>
				        </tr>
			            <tr>
			                <td>'''+local_array[0]['stream']+'''</td>
			                <td>'''+str(local_array[0]['val_1'])+'''</td>
			                <td>'''+str(local_array[0]['val_7'])+'''</td>
			                <td>'''+str(local_array[0]['val_15'])+'''</td>
			                <td>'''+str(local_array[0]['val_21'])+'''</td>
			            </tr>
					</tbody>
				</table>
				</body>
			</html>'''

	text_content = mail_string

	#Sending a mail to the
	msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, local_email_array)
	msg.attach_alternative(mail_string, "text/html")
	msg.send()

