from django import forms
from .models import *

# from .tasks import send_email_task

class ComponentForm(forms.Form):
    val_list = ComponentDetail.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
        choices=OPTIONSLIST,
        label='Select the Option',
    )

class ContactForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)

#Code for Edit options
class EditForm(forms.Form):
    # print("Printing form value ------------------")
    # id_val=0

    component_list = ComponentDetail.objects.values_list('id', 'id')
    # print(component_list)
    OPTIONSLIST = tuple(component_list)
    component = forms.MultipleChoiceField(
            choices=OPTIONSLIST,
            required=True,
            label='Select the Option',
    )

    # print("Printing id_val ",id_val)
    streams_list = StreamDetail.objects.values_list('name','id')
    OPTIONSLIST1 = tuple(streams_list)
    streams = forms.ModelChoiceField(
            queryset=StreamDetail.objects.all(),
            # choices=OPTIONSLIST1,
            widget=forms.SelectMultiple,
            # required=True,
            # label='Select the Stream Option',
    )

    email_list = AuthUser.objects.values_list('email', 'email')
    OPTIONSLIST2 = tuple(email_list)
    email = forms.MultipleChoiceField(
            choices=OPTIONSLIST2,
            required=True,
            label='Emails are',
    )

    def __init__(self, pk, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)
        # print("Setting id_val")
        # id_val=id
        self.pk=pk
        instance = CompStream.objects.filter(id=self.pk)

        for instance in instance:
            print(instance.component)
            self.initial['component'] = instance.component

            print(instance.streams)
            self.fields['streams'].queryset = StreamDetail.objects.filter(comp_id=CompStream.objects.values_list('component').filter(id=pk))
            self.initial['streams'] = instance.streams

            print(instance.email)
            self.initial['email'] = instance.email.split(",")


class FeedForm(forms.Form):
    feed_list = FeedDetail.objects.values_list('uid', 'uid')
    LIST = tuple(feed_list)








































