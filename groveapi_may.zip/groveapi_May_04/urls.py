from django.conf.urls import url
from guardian import admin
from django.contrib import admin
from . import views

admin.autodiscover()

urlpatterns = [

    #HTML Page
    url('compstream_add', views.componentview, name='componentview'),

    #Streams
    url(r'^component/validate_compid', views.streamsview, name='streamsview'),

    #Emails
    url(r'save/', views.save, name='save'),


    url(r'^(?P<id>\d+)/compstream_edit/', views.updateInformation, name='edit_post'),

    # url(r'^delete_post/', views.delete, name='delete_post'),

    url(r'feed_details/', views.feed, name='feed'),

    url(r'mail/', views.send_mail, name='send_email'),
]


