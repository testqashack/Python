from __future__ import unicode_literals
from django.db import models

class ApiDetail(models.Model):
	CHOICES = (('0', 'Development'), ('1', 'Production'))
	type = models.CharField(max_length=50, choices=CHOICES, unique=True)
	url = models.CharField(max_length=255, )
	api_key = models.CharField(max_length=255, )
	org_id = models.CharField(max_length=255, verbose_name='Organisation ID')
	dest_folder = models.CharField(max_length=255, verbose_name='Destination Folder')
	email = models.EmailField(max_length=255)
	password = models.CharField(max_length=255)

	def __str__(self):
		return str(self.pk)

#For Fetching the Email
class AuthUser(models.Model):
	password = models.CharField(max_length=128)
	last_login = models.DateTimeField(blank=True, null=True)
	is_superuser = models.BooleanField()
	username = models.CharField(unique=True, max_length=150)
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	email = models.CharField(max_length=254)
	is_staff = models.BooleanField()
	is_active = models.BooleanField()
	date_joined = models.DateTimeField()

	class Meta:
		managed = False
		db_table = 'auth_user'


# For storing details
class CompStream(models.Model):
	component = models.CharField(max_length=128, unique=True)
	streams = models.CharField(max_length=128, unique=True)
	email = models.CharField(max_length=254)

	class Meta:
		ordering = ['component']
		verbose_name = 'CompStream Information'
		verbose_name_plural = 'CompStreams Information'
		db_table = 'CompStream'



# Holds information regarding the Organization
class OrganizationDetail(models.Model):
	uid = models.UUIDField(editable=False, verbose_name='UID', unique=True)
	name = models.CharField(max_length=255, verbose_name='Organization Name', editable=False)
	address_street = models.CharField(max_length=255, verbose_name='Street', editable=False)
	address_city = models.CharField(max_length=255, verbose_name='City', editable=False)
	address_state = models.CharField(max_length=255, verbose_name='State/Province', editable=False)
	address_country = models.CharField(max_length=255, verbose_name='Country', editable=False)
	address_postalCode = models.IntegerField(verbose_name='Postal Code', editable=False)

	class Meta:
		ordering = ['name']
		verbose_name = 'Organization Information'
		verbose_name_plural = 'Organizations Information'
		db_table = 'dashboards_organizationdetail'

	def __str__(self):
		return str(self.name)


COMPONENT_PERM_VIEW_ONLY = "view_componentdetail"
COMPONENT_PERM_EDIT_TEMPLATE = "edit_template"

COMPONENT_EXTRA_PERMS = ((COMPONENT_PERM_VIEW_ONLY, "Can view Component"),
                         (COMPONENT_PERM_EDIT_TEMPLATE, "Can edit component template"),)


# Holds information regarding the components, also referred to as controllers
class ComponentDetail(models.Model):
	id = models.CharField(max_length=255, verbose_name='Component ID', editable=False, primary_key=True)
	uid = models.UUIDField(editable=False, verbose_name='UID', unique=True)
	name = models.CharField(max_length=255, verbose_name='Component Name', editable=False)
	org_id = models.ForeignKey('OrganizationDetail', verbose_name='Organization ID',editable=False)

	class Meta:
		ordering = ['name']
		verbose_name = 'Component'
		verbose_name_plural = 'Components'
		permissions = COMPONENT_EXTRA_PERMS
		db_table = 'dashboards_componentdetail'

	def __str__(self):
		return str(self.id)


# Holds information for a stream (metadata), also referred to as sensors
class StreamDetail(models.Model):
	STREAM_TYPE = (('R', 'Random'), ('I', 'INTERVAL'))

	id = models.CharField(max_length=255, primary_key=True, verbose_name='Stream ID', editable=False)
	uid = models.UUIDField(editable=False, verbose_name='UID', unique=True)
	comp_id = models.ForeignKey('ComponentDetail', verbose_name='Component ID',editable=False)
	name = models.CharField(max_length=255, verbose_name='Stream Name', editable=False)
	type = models.CharField(max_length=25, verbose_name='Stream Type', choices=STREAM_TYPE, editable=False)
	timezone = models.CharField(max_length=255, verbose_name='Time Zone', editable=False)

	class Meta:
		ordering = ['name']
		verbose_name = 'Stream'
		verbose_name_plural = 'Streams'
		db_table = 'dashboards_streamdetail'

	def __str__(self):
		return str(self.id)

# Holds information for stream data called Feed, also referred to as Sensor data
class FeedDetail(models.Model):
	id = models.BigAutoField(primary_key=True, editable=False, verbose_name='ID')
	uid = models.ForeignKey('StreamDetail', verbose_name='UID', editable=False)
	value_type = models.CharField(max_length=50, verbose_name='Value Type', editable=False)
	timestamp = models.DateTimeField(verbose_name='Timestamp', editable=False)
	value = models.DecimalField(decimal_places=2, max_digits=20, verbose_name='Value', editable=False)

	class Meta:
		ordering = ['timestamp']
		verbose_name = 'Feed'
		verbose_name_plural = 'Feeds'
		db_table = 'dashboards_feeddetail'

	def __str__(self):
		return str(self.id)
