from rest_framework import serializers

from .models import *


class ComponentSerializer(serializers.ModelSerializer):
	class Meta:
		model = ComponentDetail
		fields = ('uid', 'name')


class StreamSerializer(serializers.ModelSerializer):
	class Meta:
		model = StreamDetail
		fields = ('uid', 'name')
		depth = 1


# Used for data representation
class FeedSerializer(serializers.ModelSerializer):
	timestamp = serializers.DateTimeField()

	class Meta:
		model = FeedDetail
		fields = ('uid', 'id', 'timestamp', 'value')
		depth = 2
