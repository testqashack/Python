# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from constance import config
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.models import User
from django.shortcuts import render_to_response
from rest_framework.generics import ListAPIView

from .serializers import *


def check_user_charts_perm(user):
	if user.is_superuser:
		return True

	view_perm = user.has_perm('{0}.{1}'.format('dashboards', COMPONENT_PERM_VIEW_ONLY))
	edit_perm = user.has_perm('{0}.{1}'.format('dashboards', COMPONENT_PERM_EDIT_TEMPLATE))

	return view_perm or edit_perm


def check_user_template_perm(user):
	if user.is_superuser:
		return True

	return user.has_perm('{0}.{1}'.format('dashboards', COMPONENT_PERM_EDIT_TEMPLATE))


@user_passes_test(check_user_charts_perm)
def user_dashboard(request, template_name='dashboards/index.html'):
	components = User.objects.filter(username=request.user).values_list('components')
	view_component_perm = request.user.has_perm('{0}.{1}'.format('dashboards', COMPONENT_PERM_VIEW_ONLY))
	edit_component_perm = request.user.has_perm('{0}.{1}'.format('dashboards', COMPONENT_PERM_EDIT_TEMPLATE))

	return render_to_response(template_name, {'component'     : components, 'request': request, 'config': config,
	                                          'view_comp_perm': view_component_perm,
	                                          'edit_comp_perm': edit_component_perm})


def templating(request, template_name='dashboards/template.html'):
	return render_to_response(template_name)


# TODO: More granular filters using timestamps
# Returns the records for all the components
class ComponentListView(ListAPIView):
	serializer_class = ComponentSerializer
	queryset = ComponentDetail.objects.all()


# Returns the records for all streams for a component
class StreamListView(ListAPIView):
	serializer_class = StreamSerializer

	def get_queryset(self):
		cuid = self.kwargs['cuid']
		return StreamDetail.objects.filter(comp_id__uid=cuid)


# Returns the records from stream table for a component
class StreamDetailView(ListAPIView):
	serializer_class = StreamSerializer

	def get_queryset(self):
		cuid = self.kwargs['cuid']
		suid = self.kwargs['suid']
		return StreamDetail.objects.filter(comp_id__uid=cuid, uid=suid)


# Returns last 250 records from Feed table for a stream
class FeedDetailView(ListAPIView):
	serializer_class = FeedSerializer

	def get_queryset(self):
		uid = self.kwargs['uid']
		return FeedDetail.objects.filter(uid__uid=uid)[:250]
