# Create your Celery tasks here
from __future__ import absolute_import, unicode_literals

from datetime import datetime

from celery.task.base import periodic_task
from celery.schedules import crontab

from groveapi.api import *
from .models import *


# Looks up the database and if there is no Organization data related to the UID specified in API data,
# it will fetch the data and store in the database
@periodic_task(run_every=(crontab()), name="dashboards.tasks.save_organization_details")
def save_organization_details():
	if not OrganizationDetail.objects.filter(uid=get_org_uid()).exists():
		# Remove any stale information already present
		if OrganizationDetail.objects.filter(id=1).exists():
			OrganizationDetail.objects.get(id=1).delete()

		# Get the Organization data
		data_org = json.loads(get_organization_details())
		# Save the data in the database
		OrganizationDetail(
				uid=data_org['organization']['uid'],
				name=data_org['organization']['name'],
				address_street=data_org['organization']['address']['street'],
				address_city=data_org['organization']['address']['city'],
				address_state=data_org['organization']['address']['stateOrProvince'],
				address_country=data_org['organization']['address']['country'],
				address_postalCode=data_org['organization']['address']['postalCode']
		).save()


# Adds the components [controllers] to the database if they don't exist already
@periodic_task(run_every=(crontab()), name="dashboards.tasks.save_components")
def save_components():
	# Get the details only when we have Organization Information stored in the database
	if OrganizationDetail.objects.filter(uid=get_org_uid()).exists():
		data_comp = json.loads(get_components())

		for key, value in enumerate(data_comp):
			od = OrganizationDetail.objects.get(uid=get_org_uid())
			ComponentDetail.objects.get_or_create(id=value['id'], uid=value['uid'], name=value['text'], org_id=od)


# Adds the streams metadata [sensors] to the database if they don't exist already
@periodic_task(run_every=(crontab()), name="dashboards.tasks.save_streams")
def save_streams():
	# Fetch the component UIDs from the database
	component_uids = ComponentDetail.objects.values('uid')
	# Make sure we have component UIDs to begin with
	if component_uids:
		for component_uid in component_uids:
			# Fetch stream data for each component
			streams_data = json.loads(get_component_streams(component_uid['uid']))
			for stream in streams_data['stream']:
				# Fetch stream metadata for each stream
				metadata = json.loads(get_component_stream(component_uid['uid'], stream['uid']))['stream']
				stream_type = 'I'
				# Save metadata in database
				if metadata['streamType'] == 'rdm_stream':
					stream_type = 'R'
				cd = ComponentDetail.objects.get(uid=component_uid['uid'])
				StreamDetail.objects.get_or_create(id=metadata['id'], uid=metadata['uid'], name=metadata['name'],
				                                   comp_id=cd, timezone=metadata['timeZoneId'],
				                                   type=stream_type)


# Adds the feed data to the database if it doesn't exist already
@periodic_task(run_every=(crontab()), name='dashboards.tasks.save_feed')
def save_feed():
	# Fetch the component UIDs from the database
	component_uids = ComponentDetail.objects.values('uid')
	# Make sure we have component UIDs to begin with
	if component_uids:
		for component_uid in component_uids:
			# Fetch stream UIDs for each component from the database
			stream_uids = StreamDetail.objects.values('uid').filter(
					comp_id=ComponentDetail.objects.get(uid=component_uid['uid']))
			for stream_uid in stream_uids:
				feed_data = json.loads(get_feed_data(component_uid['uid'], stream_uid['uid']))
				sd = StreamDetail.objects.get(uid=stream_uid['uid'])
				for component in feed_data['feed']['component']:
					for stream in component['stream']:
						time = []
						data = []
						type = []
						for time_value in stream['time']:
							time.append(time_value)
						for stats in stream['statistic']:
							type = stats['type']
							for data_value in stats['data']:
								data.append(data_value)

						for i in range(len(time)):
							FeedDetail.objects.get_or_create(uid=sd, timestamp=datetime.utcfromtimestamp(time[i] /
							                                                                             1e3),
							                                 value=data[i],
							                                 value_type=type)
