# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class ApiDetail(models.Model):
	CHOICES = (('0', 'Development'), ('1', 'Production'))
	type = models.CharField(max_length=50, choices=CHOICES, unique=True)
	url = models.CharField(max_length=255, )
	api_key = models.CharField(max_length=255, )
	org_id = models.CharField(max_length=255, verbose_name='Organisation ID')
	dest_folder = models.CharField(max_length=255, verbose_name='Destination Folder')
	email = models.EmailField(max_length=255)
	password = models.CharField(max_length=255)

	class Meta:
		ordering = ['type']
		verbose_name = 'API Detail'
		verbose_name_plural = 'API Details'

	def __str__(self):
		return str(self.pk)
