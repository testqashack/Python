# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django import forms
from django.contrib import admin

from .models import *


class ApiForm(forms.ModelForm):
	class Meta:
		widgets = {'password': forms.PasswordInput}


class ApiAdmin(admin.ModelAdmin):
	list_display = ('type', 'api_key', 'org_id', 'url', 'dest_folder')
	list_display_links = ('api_key',)
	form = ApiForm


# Register your models here.
admin.site.register(ApiDetail, ApiAdmin)
