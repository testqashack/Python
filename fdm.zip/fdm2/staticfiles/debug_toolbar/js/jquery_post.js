var djdt = {jQuery: jQuery.noConflict(true)};
if (window.define) {
	window.define.amd = _djdt_define_amd_backup;
}
