from django.conf.urls import url
from groveapi_new import views
from . import views

urlpatterns = [
    #HTML Page
    url('mypage/', views.componentview, name='componentview'),

    #Streams
    url(r'^component/validate_compid', views.streamsview, name='streamsview'),

    #Emails
    url(r'save/', views.save, name='save'),

]