from __future__ import unicode_literals
from django.db import models

class ApiDetail(models.Model):
	CHOICES = (('0', 'Development'), ('1', 'Production'))
	type = models.CharField(max_length=50, choices=CHOICES, unique=True)
	url = models.CharField(max_length=255, )
	api_key = models.CharField(max_length=255, )
	org_id = models.CharField(max_length=255, verbose_name='Organisation ID')
	dest_folder = models.CharField(max_length=255, verbose_name='Destination Folder')
	email = models.EmailField(max_length=255)
	password = models.CharField(max_length=255)

	def __str__(self):
		return str(self.pk)

class Component(models.Model):
	id = models.CharField(max_length = 100, primary_key=True, unique=True, null=False)
	uid = models.CharField(max_length=30)
	name = models.CharField(max_length=30)
	org_id_id = models.CharField(max_length=30)

	class Meta:
		db_table = 'dashboards_componentdetail'

class Stream(models.Model):
	id = models.IntegerField(primary_key=True, unique=True, null=False)
	uid = models.IntegerField()
	name = models.CharField(max_length=30)
	type = models.CharField(max_length=30)
	timezone = models.CharField(max_length=30)
	comp_id = models.ForeignKey(Component, related_name='streams')

	class Meta:
		ordering = ['name']
		verbose_name = 'Stream'
		verbose_name_plural = 'Streams'
		db_table = 'dashboards_streamdetail'

	def __str__(self):
		return str(self.id)

#For Fetching the Email
class AuthUser(models.Model):
	password = models.CharField(max_length=128)
	last_login = models.DateTimeField(blank=True, null=True)
	is_superuser = models.BooleanField()
	username = models.CharField(unique=True, max_length=150)
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	email = models.CharField(max_length=254)
	is_staff = models.BooleanField()
	is_active = models.BooleanField()
	date_joined = models.DateTimeField()

	class Meta:
		managed = False
		db_table = 'auth_user'


#NEW TABLE
class CompStream(models.Model):
	component = models.CharField(max_length=128, unique=True)
	streams = models.CharField(max_length=128, unique=True)
	email = models.CharField(max_length=254)

	class Meta:
		managed = False
		db_table = 'CompStream'



