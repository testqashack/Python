from django import forms
from .models import *

class MailForm(forms.Form):
    id = forms.IntegerField()
    uid = forms.IntegerField()
    name = forms.CharField(max_length=30)
    type = forms.CharField(max_length=30)
    timezone = forms.CharField(max_length=30)
    comp_id = forms.CharField(max_length=30)

class ComponentForm(forms.Form):
    val_list = Component.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
        choices=OPTIONSLIST,
        initial='0',
        widget=forms.SelectMultiple(),
        required=True,
        label='Select the Option',
    )

class ContactForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)






