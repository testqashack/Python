from django.core import serializers
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.shortcuts import render, get_object_or_404, redirect, render_to_response
from django.views import generic

from .forms import *
from .models import CompStream

#Mypage view function for ComponentForm
def componentview(request):
    compIdVal = ''

    form = ComponentForm(request.POST)
    print(form)

    componentVal = form.cleaned_data.get('componentsList')
    print(componentVal)

    if componentVal != None:
        compIdVal = componentVal[0]
    print(compIdVal)

    details = Stream.objects.filter(comp_id_id = compIdVal)
    print(details)

    #For Send email
    contactform = ContactForm(request.POST)
    print(contactform)

    contactform = AuthUser(request.POST)
    contactform = AuthUser.objects.all()

    edit_form = CompStream(request.POST)
    edit_form = CompStream.objects.all()

    return render(request, 'mypage.html', locals())

def streamsview(request):
    compId = request.GET.get('comp_id', None)
    print(compId)
    data = {
        'comp_info': serializers.serialize("json",Stream.objects.filter(comp_id = compId))
    }
    print ('----------------------------')
    print ('JSON Format data',data)
    print ('----------------------------')
    return JsonResponse(data)

def save(request):
    c_form = ContactForm(request.POST)

    if c_form.is_valid():
        component = request.POST.get('componentsList', '')
        streams = request.POST.get('model', '')
        email = request.POST.get('mail', '')
        print(
            'Component:'+component,
            'Stream:'+streams,
            'email:'+email
        )

        comp_obj = CompStream(component=component, streams=streams, email=email)
        comp_obj.save()

        # return HttpResponse("Data Saved Suessfully")
        return redirect('/mypage')

    else:
        c_form = ContactForm()

    return render(request, 'mypage.html', {'c_form': c_form, })


# def new_post(request):
#     template = 'new_post.html'
#     n_form = EditForm(request.POST or None)
#
#     try:
#         if n_form.is_valid():
#             n_form.save()
#             messages.success(request, 'Your Blog Post Was Successfully Saved')
#         else:
#             n_form = EditForm()
#
#     except Exception as e:
#         messages.warning(request, "Blog Post Failed To Save. Error: {}".format(e))
#
#     context = {
#         'n_form': n_form,
#     }
#
#     return render(request, template, context)

#
# #Edit Post
# def edit_post(request, s):
#     print('------------------------------')
#     print(request)
#     print('------------------------------')
#     # template = 'mypage.html'
#     # post = get_object_or_404(Post, pk=s)
#
#     compIdVal = ''
#
#     edit_form = ComponentForm(request.POST)
#     print(edit_form)
#
#     componentVal = edit_form.cleaned_data.get('componentsList')
#     print(componentVal)
#
#     if componentVal != None:
#         compIdVal = componentVal[0]
#     print(compIdVal)
#
#
#     # if request.method == 'GET':
#     #     edit_form = EditForm(request.GET)
#     #     try:
#     #         if edit_form.is_valid():
#     #             edit_form.save()
#     #             # return redirect('new_post', post)
#     #             messages.success(request, "Your Data Was Successfully Updated")
#     #
#     #     except Exception as e:
#     #         messages.warning(request, 'Your Data Was Not Saved Due To An Error: {}'.format(e))
#     #
#     # else:
#     #     edit_form = EditForm()
#
#     return render(request, "new_post.html", {"edit_form" : edit_form})

#
# def post_list_admin(request):
#     template = 'blog/form-template.html'
#
#     post = Post.objects.all()
#
#     pages = pagination(request, post, 5)
#
#     context = {
#         'items': pages[0],
#         'page_range': pages[1]
#     }
#     return render(request, template, context)




# def edit_post(request, id=None, template_name='mypage.html'):
#     if id:
#         post = get_object_or_404(CompStream, pk=id)
#         if post.author != request.user:
#             return HttpResponseForbidden()
#     else:
#         post = CompStream(author=request.user)
#
#     edit_form = EditForm(request.POST or None, instance=post)
#     if request.POST and edit_form.is_valid():
#         edit_form.save()
#
#         # Save was successful, so redirect to another page
#         redirect_url = reverse('/')
#         return redirect(redirect_url)
#
#     return render(request, template_name, {
#         'edit_form': edit_form
#     })

def updateInformation(request, id=None):
    print id
    instance = CompStream.objects.values_list('component', flat=True).filter(id=id)
    print instance[0]
    print(get_object_or_404(instance, component=CompStream.component))
    # print instance.component
    # print instance.streams
    # print instance.email

    edit_form = EditForm(request.POST or None)
    # edit_form.save()
    # instance.save()

    context = {
        "title":"Edit form",
        "instance":instance,
        "form":edit_form,
    }
    return render(request, "new_post.html", context)


# from django.views.generic import UpdateView
#
#
# # view for the index page
# class IndexView(generic.ListView):
#     # name of the object to be used in the index.html
#     context_object_name = 'edit_form'
#     template_name = 'mypage.html'
#
#     def get_queryset(self):
#         return CompStream.objects.all()
#
#
# class InfoUpdate(UpdateView):
#
#     model = CompStream
#     # template_name = "new_post.html";
#     fields = ['component','streams','email','id']
#
#     def get_success_url(self):
#         from django.urls import reverse
#         return reverse('mypage', kwargs={
#             'pk': self.object.pk,
#         })