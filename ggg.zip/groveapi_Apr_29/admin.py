from __future__ import unicode_literals
from django import forms
from django.contrib import admin
from .models import *

class ApiAdmin(admin.ModelAdmin):
	list_display = ('email',)

class ComponentAdmin(admin.ModelAdmin):
	list_display = ('id', 'uid' ,'name')
	# list_display = ('id', 'uid' ,'name', 'org_id')

class StreamAdmin(admin.ModelAdmin):
		list_display = ('id', 'uid' ,'name', 'comp_id', 'type','timezone')

class FeedAdmin(admin.ModelAdmin):
		list_display = ('id', 'uid' ,'value_type', 'timestamp', 'value')

class CompStreamAdmin(admin.ModelAdmin):
	list_display = ('component', 'streams', 'email')

	class Media:
		js = (
			'//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js',
			'js/custom.js',
		)


admin.site.register(AuthUser, ApiAdmin)
admin.site.register(ComponentDetail, ComponentAdmin)
admin.site.register(StreamDetail, StreamAdmin)
admin.site.register(CompStream, CompStreamAdmin)
admin.site.register(FeedDetail,FeedAdmin)
# admin.site.register(OrganizationDetail)
