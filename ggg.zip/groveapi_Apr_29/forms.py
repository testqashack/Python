from django import forms
from .models import *

class ComponentForm(forms.Form):
    val_list = ComponentDetail.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
        choices=OPTIONSLIST,
        label='Select the Option',
    )

class ContactForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)

#Code for Edit options
class EditForm(forms.Form):
    component_list = ComponentDetail.objects.values_list('id', 'id')
    OPTIONSLIST = tuple(component_list)
    component = forms.MultipleChoiceField(
            choices=OPTIONSLIST,
            required=True,
            label='Select the Option',
    )

    streams_list = StreamDetail.objects.values_list('id', 'id')
    OPTIONSLIST1 = tuple(streams_list)
    streams = forms.MultipleChoiceField(
        choices=OPTIONSLIST1,
        required=True,
        label='Select the Stream Option',
    )

    email_list = AuthUser.objects.values_list('id','email')
    OPTIONSLIST2 = tuple(email_list)
    email = forms.MultipleChoiceField(
        choices=OPTIONSLIST2,
        required=True,
        label='Emails are',
    )

    def __init__(self, pk, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)
        self.pk=pk
        instance = CompStream.objects.filter(id=self.pk)

        for instance in instance:
            print(instance.component)
            self.initial['component'] = instance.component

            print(instance.streams)
            self.initial['streams'] = instance.streams

            print(instance.email)
            self.initial['email'] = instance.email

class FeedForm(forms.Form):
    feed_list = FeedDetail.objects.values_list('uid', 'uid')
    LIST = tuple(feed_list)


