from django import forms
from .models import *

class MailForm(forms.Form):
    id = forms.IntegerField()
    uid = forms.IntegerField()
    name = forms.CharField(max_length=30)
    type = forms.CharField(max_length=30)
    timezone = forms.CharField(max_length=30)
    comp_id = forms.CharField(max_length=30)

class ComponentForm(forms.Form):
    val_list = Component.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
        choices=OPTIONSLIST,
        #initial='0',
        #widget=forms.SelectMultiple(),
        #required=True,
        label='Select the Option',
    )

class ContactForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)

class EditForm(forms.Form):
    # val_list = Component.objects.values_list('id', 'id')
    # OPTIONSLIST = tuple(val_list)
    # componentsList = forms.MultipleChoiceField(
    #         choices=OPTIONSLIST,
    #         initial='0',
    #         # widget=forms.SelectMultiple(),
    #         # required=True,
    #         label='Select the Option',
    # )

    # streams = models.CharField(max_length=128, unique=True)
    # email = models.CharField(max_length=254, unique=True)
    # id = models.IntegerField(max_length=50,unique=True)


    def __init__(self, pk, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)
        self.pk=pk
#        print("constructor called")
        instance = CompStream.objects.filter(id=self.pk)
#        print(instance)
        for instance in instance:
#            print(instance.component)

            val_list = Component.objects.values_list('id', 'id')
            OPTIONSLIST = tuple(val_list)
            componentsList = forms.MultipleChoiceField(
                    choices=OPTIONSLIST,

                    # widget=forms.SelectMultiple(),
                    # required=True,
                    label='Select the Component',
            )
            self.initial['component'] = instance.component

            val_list1 = Stream.objects.values_list('id', 'id')
            OPTIONSLIST1 = tuple(val_list1)
            #print(OPTIONSLIST1)
            streamsList = forms.MultipleChoiceField(
                    choices=OPTIONSLIST1,

                    # widget=forms.SelectMultiple(),
                    # required=True,
                    label='Select the Streams',
            )

            # val_list2 = email.objects.values_list('id', 'id')
            # OPTIONSLIST2 = tuple(val_list2)
            # #print(OPTIONSLIST1)
            # emailList = forms.MultipleChoiceField(
            #         choices=OPTIONSLIST2,
            #
            #         # widget=forms.SelectMultiple(),
            #         # required=True,
            #         label='Select the Email',
            # )

            self.fields['component'] = componentsList
            self.fields['streams'] = streamsList
            # self.fields['email'] = emailList

    class Meta:
        model = CompStream
        fields = [
            "component",
            "streams",
            "email"
        ]