from django.conf.urls import url
from groveapi import views
from . import views
# from .views import edit_post
    # ,new_post,post_list_admin

urlpatterns = [
    #HTML Page
    url('mypage', views.componentview, name='componentview'),

    # url('new_post/', views.edit_post, name='editview'),

    #Streams
    url(r'^component/validate_compid', views.streamsview, name='streamsview'),

    #Emails
    url(r'save/', views.save, name='save'),

    #timezone
    url(r'set_timezone/', views.set_timezone, name='set_timezone'),

    #admin

    # url(r'^new_post/', new_post, name='new_post'),
    # url(r'^edit_post/(?P<s>\d+)/', edit_post, name='edit_post'),

    # url(r'^edit_post/(?P<pk>\d+)/', views.InfoUpdate.as_view(), name='edit_post'),
    url(r'^(?P<id>\d+)/edit_post/', views.updateInformation, name='edit_post'),
    url(r'save_feed/', views.save_feed, name='save_feed'),

    url(r'feed/', views.feed, name='feed'),


]


