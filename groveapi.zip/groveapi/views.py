import json
import pytz
from django.core import serializers
from django.http import HttpResponse, JsonResponse, HttpResponseForbidden
from django.shortcuts import render, get_object_or_404, redirect, render_to_response
from django.forms import modelformset_factory
from .forms import *
from .models import CompStream

#Mypage view function for ComponentForm
def componentview(request):
    compIdVal = ''

    form = ComponentForm(request.POST)
    print(form)

    componentVal = form.cleaned_data.get('componentsList')
    print(componentVal)

    if componentVal != None:
        compIdVal = componentVal[0]
    print(compIdVal)

    # details = Stream.objects.filter(comp_id_id = compIdVal)
    details = StreamDetail.objects.filter(comp_id_id = compIdVal)
    print(details)

    #For Send email
    contactform = ContactForm(request.POST)
    print(contactform)

    contactform = AuthUser(request.POST)
    contactform = AuthUser.objects.all()

    edit_form = CompStream(request.POST)
    edit_form = CompStream.objects.all()

    return render(request, 'mypage.html', locals())

def streamsview(request):
    compId = request.GET.get('comp_id', None)
    print(compId)
    data = {
        'comp_info': serializers.serialize("json", StreamDetail.objects.filter(comp_id=compId))
    }
    print ('----------------------------')
    print ('JSON Format data',data)
    print ('----------------------------')
    return JsonResponse(data)

def save(request):
    c_form = ContactForm(request.POST)

    if c_form.is_valid():
        component = request.POST.get('componentsList', '')
        streams = request.POST.get('model', '')
        email = ''
        for key in request.POST:
            if 'email' in key:
                email = email+request.POST[key]+','

        comp_obj = CompStream(component=component, streams=streams, email=email)
        comp_obj.save()

        return redirect('/mypage')
    else:
        c_form = ContactForm()

    return render(request, 'mypage.html', {'c_form': c_form, })


def updateInformation(request, id=None):
    print id
    edit_form = EditForm(id)
    context = {
        "title":"Edit form",
        "form":edit_form,
    }
    return render(request, "edit_post.html", context)




def updateform(request, id=None):
    updateformset = modelformset_factory(CompStream, fields=('component','streams','email'))
    data = request.POST or None
    formset = updateformset(data=data, queryset=CompStream.objects.filter(id=id))
    print(formset)
    for form in formset:
        form.fields['streams'].queryset = StreamDetail.objects.filter(id=id)

    return render(request, 'edit_post.html',{'formset':formset})





def save_feed(request):
    print 'Savefeed request : ',request

    component_uids = ComponentDetail.objects.values('uid')
    print '----------------------------------------------------------'
    print 'Component UIDS : ',component_uids
    print '----------------------------------------------------------'
    if component_uids:
        for component_uid in component_uids:
            print 'UID',component_uid
            stream_uids = StreamDetail.objects.values('uid').filter(
                comp_id=ComponentDetail.objects.get(uid=component_uid['uid']))
            print '----------------------------------------------------------'
            print 'Stream UIDS : ',stream_uids
            print '----------------------------------------------------------'

            for stream_uid in stream_uids:
                print 'S UID',stream_uid
                # feed_data = json.loads(get_feed_data(component_uid['uid'], stream_uid['uid']))
                feed_data = {
                    'get_feed_data': json.loads(component_uid['uid'], stream_uid['uid'])
                }

                # feed_data = json.loads('{"component_uid": uid, "stream_uid": uid}')
                # sd = StreamDetail.objects.get(uid=stream_uid['uid'])

                for component in feed_data['feed']['component']:
                    for stream in component['stream']:
                        time = []
                        data = []
                        type = []
                        for time_value in stream['time']:
                            time.append(time_value)
                        for stats in stream['statistic']:
                            # type = stats['type']
                            for data_value in stats['data']:
                                data.append(data_value)
                            print('The data is', data)
                        #omponent UIDS :  <QuerySet [{'uid': UUID('a9ac53bb-c9ec-302e-a782-500f14a13c07')}, {'uid': UUID('06ac30ca-2d37-3737-8c9a-497f3a3e2bd1')}, {'uid': UUID('67b712a9-39b7-3e3b-9404-ca6db37be3a9')}, {'uid': UUID('e7dfd9ec-662f-3743-82f8
                        # for i in range(len(time)):
                        #     FeedDetail.objects.get_or_create(uid=sd, timestamp=datetime.utcfromtimestamp(time[i] / 1e3),
                        #                                      value=data[i],value_type=type)





def feed(request):
    print 'REQ', request

    feed_form = FeedForm(request.POST)
    feed_form = FeedDetail.objects.all()

    print(feed_form)

    # u = FeedDetail.objects.get('uid')
    # print'Data',u
    # # feed_uid = FeedDetail.objects.filter('uid')
    # # feed_value = FeedDetail.objects.get('value')
    #
    # # name = FeedDetail.objects.filter('uid').values_list('name', flat=True)
    #
    # feed_list = FeedDetail.objects.values_list('id','uid')
    #
    # print '---------------------------'
    # print 'Feed Details are ', feed_form
    #
    # # print 'Feed Details are ', feed_uid
    #
    # # print 'Feed Details are ', name
    # print '---------------------------'
    # print 'Feed Details with ids are ', feed_list
    # print '---------------------------'
    #
    # # print 'Feed Values are ', feed_value
    # print '---------------------------'
    #
    # if StreamDetail.id and FeedDetail.uid == 'Cooling Tower 1: Bleed_2':
    #     print "IDS:", StreamDetail.id


    query_results = list()
    feed_s = StreamDetail.objects.all()
    for feeds in feed_s:
        feed_list = FeedDetail.objects.filter(uid=feeds)
        for feed in feed_list:
            element = FeedDetail_new()
            element.id = feed.id
            element.uid= feeds.uid
            # element.values= feeds.value
            query_results.append(element)

        if feed_s.__len__() == 0:
            element = FeedDetail_new()
            element.uid= 'Cooling Tower 2: Temperature'
            element.id= feeds.id
            element.value = feed_list.value
            query_results.append(element)


    return render(request, 'feed.html', locals())










def set_timezone(request):
    if request.method == 'POST':
        request.session['django_timezone'] = request.POST['timezone']
        return redirect('/')
    else:
        return render(request, 'template.html', {'timezones': pytz.common_timezones})














