from django.core import serializers
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from .forms import *
from .models import *

#Mypage view function for ComponentForm
def componentview(request):
    compIdVal = ''

    form = ComponentForm(request.POST)
    print(form)

    componentVal = form.cleaned_data.get('componentsList')
    print(componentVal)

    if componentVal != None:
        compIdVal = componentVal[0]
    print(compIdVal)

    details = Stream.objects.filter(comp_id_id = compIdVal)
    print(details)

    #For Send email
    contactform = ContactForm(request.POST)
    print(contactform)

    contactform = AuthUser(request.POST)
    contactform = AuthUser.objects.all()
    return render(request, 'mypage.html', locals())

def streamsview(request):
    compId = request.GET.get('comp_id', None)
    print(compId)
    data = {
        'comp_info': serializers.serialize("json",Stream.objects.filter(comp_id = compId))
    }
    print ('----------------------------')
    print ('JSON Format data',data)
    print ('----------------------------')
    return JsonResponse(data)

def save(request):
    c_form = ContactForm(request.POST)

    if c_form.is_valid():
        component = request.POST.get('componentsList', '')
        streams = request.POST.get('model', '')
        email = request.POST.get('mail', '')
        print(
            'Component:'+component,
            'Stream:'+streams,
            'email:'+email
        )

        comp_obj = CompStream(component=component, streams=streams, email=email)
        comp_obj.save()

        return HttpResponse("Data Saved Suessfully")

    else:
        c_form = ContactForm()

    return render(request, 'mypage.html', {'c_form': c_form, })


def edit(request):
    info = CompStream.objects.all()
    print '+++++++++Info++++++',info
    if request.POST:
        email = request.POST.get('sid')
        edi = info.get(sid = s.mail)
        edi = request.POST.get('script')
        edit.save()
        return render(request,'edit.html',locals())
