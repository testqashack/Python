from __future__ import unicode_literals
from django import forms
from django.contrib import admin
from .models import *

class ApiForm(forms.ModelForm):
	class Meta:
		widgets = {'password': forms.PasswordInput}

class UserForm(forms.ModelForm):
	class Meta:
		widgets = {'password': forms.PasswordInput}

class ComponentAdmin(admin.ModelAdmin):
	pass

class StreamAdmin(admin.ModelAdmin):
	pass

class CompStreamAdmin(admin.ModelAdmin):
	list_display = ('component', 'streams', 'email', 'id')
	list_display_links = ('id',)
	search_fields = ('component', 'streams', 'email')
	list_per_page = 25
	readonly_fields = ('component', 'streams', 'email', 'id')


admin.site.register(CompStream)
admin.site.register(ComponentDetail, ComponentAdmin)
admin.site.register(StreamDetail, StreamAdmin)
