from django import forms
from .models import *

class ComponentForm(forms.Form):
    val_list = ComponentDetail.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
        choices=OPTIONSLIST,
        label='Select the Option',
    )

class ContactForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)

class EditForm(forms.Form):
    component_list = ComponentDetail.objects.values_list('id', 'id')
    OPTIONSLIST = tuple(component_list)
    component = forms.MultipleChoiceField(
            choices=OPTIONSLIST,
            required=True,
            label='Select the Option',
    )

    streams_list = StreamDetail.objects.values_list('id', 'id')
    OPTIONSLIST1 = tuple(streams_list)
    streams = forms.MultipleChoiceField(
        choices=OPTIONSLIST1,
        required=True,
        label='Select the Stream Option',
    )

    email_list = AuthUser.objects.values_list('id','email')
    OPTIONSLIST2 = tuple(email_list)
    email = forms.MultipleChoiceField(
        choices=OPTIONSLIST2,
        required=True,
        label='Emails are',
    )

    def __init__(self, pk, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)
        self.pk=pk
        instance = CompStream.objects.filter(id=self.pk)

        for instance in instance:
            print(instance.component)
            self.initial['component'] = instance.component

            print(instance.streams)
            self.initial['streams'] = instance.streams

            print(instance.email)
            self.initial['email'] = instance.email

def save_feed():
    print 'dataaaaaaaaaaaa'
    component_uids = ComponentDetail.objects.values('uid')
    print('comp..',component_uids)
    if component_uids:
        for component_uid in component_uids:
            stream_uids = StreamDetail.objects.values('uid').filter(
                comp_id=ComponentDetail.objects.get(uid=component_uid['uid']))
            for stream_uid in stream_uids:
                feed_data = json.loads(get_feed_data(component_uid['uid'], stream_uid['uid']))
                # sd = StreamDetail.objects.get(uid=stream_uid['uid'])
                for component in feed_data['feed']['component']:
                    for stream in component['stream']:
                        time = []
                        data = []
                        type = []
                        for time_value in stream['time']:
                            time.append(time_value)
                        for stats in stream['statistic']:
                            # type = stats['type']
                            for data_value in stats['data']:
                                data.append(data_value)
                            print('The data is', data)


class FeedForm(forms.Form):
    feed_list = FeedDetail.objects.values_list('uid', 'uid')
    LIST = tuple(feed_list)

class TempObjectForStudent():
    student_name = None
    parent_name = None
    parent_phone = None





