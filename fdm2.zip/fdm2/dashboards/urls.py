from django.conf.urls import url, include

from . import views

urlpatterns = [
	url(r'^$', views.user_dashboard, name='index'),
	url(r'^template', views.templating, name='templating'),
	url(r'^api/components/$', views.ComponentListView.as_view(), name='components_list'),
	url(r'^api/component/(?P<cuid>([a-z0-9]*-[a-z0-9]*)+)/streams/$', views.StreamListView.as_view(),
	    name='streams_list'),
	url(r'^api/component/(?P<cuid>([a-z0-9]*-[a-z0-9]*)+)/stream/(?P<suid>([a-z0-9]*-[a-z0-9]*)+)/$',
	    views.StreamDetailView.as_view(), name='stream_detail'),
	url(r'^api/feed/(?P<uid>([a-z0-9]*-[a-z0-9]*)+)/$', views.FeedDetailView.as_view(), name='feed_detail'),
	url(r'^api/auth/', include('rest_framework.urls'))
]
