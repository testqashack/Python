# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

from .models import *


class OrganizationAdmin(admin.ModelAdmin):
	list_display = ('uid', 'name')
	list_display_links = ('uid',)
	list_per_page = 25
	search_fields = ('uid', 'name')
	readonly_fields = (
		'uid', 'name', 'address_street', 'address_city', 'address_state', 'address_country', 'address_postalCode')


class ComponentAdmin(admin.ModelAdmin):
	list_display = ('uid', 'name', 'id')
	list_display_links = ('uid',)
	search_fields = ('uid', 'name', 'id')
	list_per_page = 25
	readonly_fields = ('id', 'uid', 'name', 'org_id')


class StreamAdmin(admin.ModelAdmin):
	list_display = ('uid', 'id', 'name', 'comp_id', 'type', 'timezone')
	list_display_links = ('uid', 'id', 'name')
	search_fields = ('uid', 'id', 'name', 'comp_id__uid', 'type', 'timezone')
	list_per_page = 25
	readonly_fields = ('uid', 'id', 'name', 'comp_id', 'type', 'timezone')


class FeedAdmin(admin.ModelAdmin):
	list_display = ('id', 'uid', 'timestamp', 'value', 'value_type')
	list_display_links = ('id',)
	search_fields = ('id', 'uid__uid', 'timestamp', 'value', 'value_type')
	list_per_page = 25
	readonly_fields = ('id', 'uid', 'timestamp', 'value', 'value_type')

# components = models.ManyToManyField(ComponentDetail, blank=True)
# components.contribute_to_class(User, 'components')


# class UserAdminX(UserAdmin):
# 	fieldsets = UserAdmin.fieldsets + (
# 		(None, {'fields': ('components',)},),
# 	)
# 	filter_horizontal = UserAdmin.filter_horizontal + ('components',)

admin.site.register(OrganizationDetail, OrganizationAdmin)
admin.site.register(ComponentDetail, ComponentAdmin)
admin.site.register(StreamDetail, StreamAdmin)
admin.site.register(FeedDetail, FeedAdmin)


# admin.site.unregister(User)
# admin.site.register(User, UserAdminX)
