    <!--Javascript, Jquery  code for display a sutopopulate the stream details-->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"> </script>
        <script>
            $("#id_componentsList").change(function () {
                for(var x=0; x< $(this).val().length; x++){
                    if($('select#model-'+x).length < 1){
                        $('.streams-container').append('<select style="margin-bottom:10px;" name="model-'+x+'" id="model-'+x+'" disabled="true" multiple class="selectpicker form-control" required="True"></select>')
                    }
                    var id = $(this).val()[x];

                    $.ajax({
                        url: '/component/validate_compid/',
                        data: {
                            'comp_id': id
                        },
                        // cache: false,
                        dataType: 'json',
                        success: function (data) {
                            console.log(data)

                            recordsArray = JSON.parse(data['comp_info'])
                            console.log(recordsArray.length)

                            if(recordsArray.length > 0){
                                $('#model-'+(x-1)).css('display','block');
                            }

                            var options = '';
                            for (var i = 0; i < recordsArray.length; i++) {
                                options += '<option value="' + recordsArray[i]['pk'] + '">' + recordsArray[i].fields['name'] + '</option>';
                            }

                            console.log(options)
                            $("select#model-"+(x-1)).html(options);
                            $("select#model-"+(x-1)).attr('disabled', false);

                            // $('select#model-'+x).multiSelect('deselect',true);
                            // $('select#model-'+x).removeAttr("selected", false)
                            // a=$("select#model-"+(x-1)).remove();
                            console.log(a)
                            // $("select#model- option:selected").removeAttr('#model-'+x,true);

                        }
                    });
                    a=$("select#model-"+(x-1)).remove();

                }
            });
        </script>

    <!--Code for 'Add more Button for add the more email ids'-->
        <script>
            $(document).ready(function() {
                var max_fields = 15; //maximum input boxes allowed
                var wrapper = $(".input_fields_wrap"); //Fields wrapper
                var add_button = $(".add_field_button"); //Add button ID

                var x = 0; //initlal text box count
                $(add_button).click(function(e) {
                    e.preventDefault();
                    if (x < max_fields) {
                        x++;

                        //Code to enter more email id
                        $(wrapper).append('<div><input pattern="[^@]+@[^@]+\\.[a-zA-Z]{2,6}" placeholder="Enter the email address" type="text" name="email-'+x+'"/><a href="#" class="remove_field">Remove</a></div>'); //add input box

                    }
                });

                $(wrapper).on("click", ".remove_field", function(e) {
                    e.preventDefault();
                    $(this).parent('div').remove();
                    x--;
                })
            });
        </script>

    <!--js code function for confirm to Submit data-->
        <script>
            function clicked(e)
            {
                var add=$("#id_componentsList").val();
                console.log(add)
                if(!confirm('Are you sure?'))e.preventDefault();
            }
        </script>

        <!--Validate email address-->
        <script>
            function clicked1(e1)
            {
                var pattern = $("^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$").val();

                if (pattern.test(email-'x'))
                    alert(str.match(pattern));
                return str.match(pattern);
            }
        </script>

