# from constance import config
from django.conf.urls import url, include
from django.contrib import admin
from django.conf import settings

urlpatterns = [
	# url(r'^admin_tools/', include('admin_tools.urls')),
	url(r'^accounts/', include('allauth.urls')),
	url(r'^cp/', admin.site.urls),
	# url(r'^admin/', admin.site.urls),

	url(r'^', include('dashboards.urls')),

	url(r'^', include('groveapi.urls')),

	url(r'^', include('email_report.urls')),
]

if settings.DEBUG:
	import debug_toolbar

	urlpatterns = [url(r'^__debug__/', include(debug_toolbar.urls))] + urlpatterns