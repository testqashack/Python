"""
This is a wrapper for Grovestream API which is core part for this application. It retrieves all the information using
GET requests.
"""

import json
import logging

import requests
from django.conf import settings
from django.core.cache import cache
from retrying import retry

from .models import *

from django.utils import timezone


# Fetches all values from API Detail table based on DEBUG value
def _api_detail():
	_api = None
	if settings.DEBUG:
		# Get all development values
		if ApiDetail.objects.filter(type='0').exists():
			_api = ApiDetail.objects.get(type='0')
	else:
		# Get all production values
		if ApiDetail.objects.filter(type='1').exists():
			_api = ApiDetail.objects.get(type='1')

	if _api:
		return json.dumps(
				{'url'     : _api.url,
				 'api_key' : _api.api_key,
				 'org'     : _api.org_id,
				 'dest'    : _api.dest_folder,
				 'email'   : _api.email,
				 'password': _api.password})
	else:
		return json.dumps({'error': 'API data is missing.'})


# Fetches the API information from cache if possible reducing database hits
def _api_instance():
	# If cache is not set
	if cache.get('api_detail') is None:
		# Make sure there is no error
		if 'error' not in _api_detail():
			return cache.get_or_set('api_detail', json.loads(_api_detail()))
		else:
			# Clear cache and return error
			cache.clear()
			return _api_detail()
	else:
		# Return valid data
		return cache.get('api_detail')


# Construct URL
def _url(path):
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, construct the URL
	if 'error' not in api:
		return api['url'] + path
	else:
		return api


# Get the API Key
def _api_key():
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, return API Key
	if 'error' not in api:
		return api['api_key']
	else:
		return api


# Get the Organisation ID
def _org_id():
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, return Organisation ID
	if 'error' not in api:
		return api['org']
	else:
		return api


# Get the destination folder
def _dest_folder():
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, return destination folder
	if 'error' not in api:
		return api['dest']
	else:
		return api


# Get the email
def _email():
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, return email
	if 'error' not in api:
		return api['email']
	else:
		return api


# Get the password
def _password():
	# Get all API data from cache
	api = _api_instance()

	# If there is no error, return password
	if 'error' not in api:
		return api['password']
	else:
		return api


# Process GET requests using _get function for easy debugging and reties on errors
@retry(stop_max_attempt_number=5, stop_max_delay=30000, wait_random_min=10000, wait_random_max=15000,
       retry_on_result=None)
def _get(url, **kwargs):
	result = requests.get(url, **kwargs)

	log = logging.getLogger(__name__)
	log.info("HTTP request performed to: {0} [status: {1}]".format(url, result.status_code))

	if int(result.status_code) == requests.codes.internal_server_error:
		log.error("Internal Server Error")
		raise Exception("Unable to retrieve data at the moment.")
	elif int(result.status_code) == requests.codes.bad_request:
		log.error("Bad Request")
		raise Exception("Bad request: {0}".format(url))
	elif int(result.status_code) == requests.codes.unauthorized or int(result.status_code) == requests.codes.forbidden:
		log.error("Unauthorized request")
		raise Exception("You don't have enough permissions to perform the request.")
	elif int(result.status_code) == requests.codes.service_unavailable:
		log.error("Service Unavailable")
		raise Exception("Service Unavailable at the moment. Please try again after some time.")

	return result


# Process POST requests using _post function for easy debugging and reties on errors
@retry(stop_max_attempt_number=5, stop_max_delay=30000, wait_random_min=10000, wait_random_max=15000,
       retry_on_result=None)
def _post(url, data=None, json=None, **kwargs):
	result = requests.post(url, data, json, **kwargs)

	log = logging.getLogger(__name__)
	log.info("HTTP request performed to: {0} [status: {1}]".format(url, result.status_code))

	if int(result.status_code) == requests.codes.internal_server_error:
		log.error("Internal Server Error")
		raise Exception("Unable to retrieve data at the moment.")
	elif int(result.status_code) == requests.codes.bad_request:
		log.error("Bad Request")
		raise Exception("Bad request: {0}".format(url))
	elif int(result.status_code) == requests.codes.unauthorized or int(result.status_code) == requests.codes.forbidden:
		log.error("Unauthorized request")
		raise Exception("You don't have enough permissions to perform the request.")
	elif int(result.status_code) == requests.codes.service_unavailable:
		log.error("Service Unavailable")
		raise Exception("Service Unavailable at the moment. Please try again after some time.")

	return result


# Get session UID
def _session_uid():
	if cache.get('sessionUid') is None:

		# Get the session UID
		suid = _post(_url('/api/login'), json={'email': _email(), 'password': _password()})

		if suid.status_code == requests.codes.ok:
			# Set session ID in cache for 30 minutes
			return cache.get_or_set('sessionUid', str(json.loads(suid.text)['sessionUid']), 1800)
		else:
			cache.clear()
			return json.dumps({'error': 'Cannot fetch Session UID'})
	else:
		return cache.get('sessionUid')


# Get UID for destination folder
def _dest_folder_uid():
	# Get current session UID
	suid = _session_uid()
	# Get destination folder under Components
	dest = (_dest_folder()).split('/')[-1]

	if suid is not None:
		# Get the parent UID of Components folder
		if cache.get('destFolderUid') is None:
			parent_res = _get(_url('/api/cr/comp?session={s}&org={o}'.format(s=suid, o=_org_id())))

			if parent_res.status_code == requests.codes.ok:
				parent_uid = json.loads(parent_res.text)['cr_node']['uid']

				# Get destination folder UID
				dest_res = _get(
						_url('/api/cr/comp/{p}/children?session={s}&org={o}').format(p=parent_uid, s=suid,
						                                                             o=_org_id()))
				if dest_res.status_code == requests.codes.ok:
					dest_uid = json.loads(dest_res.text)
					value = None
					for uid in dest_uid['cr_node']['children']:
						# Check for the text with 'dest' folder and select its UID
						if uid['text'] == dest:
							value = uid['uid']
					return cache.get_or_set('destFolderUid', value)
				else:
					cache.clear()
					return json.dumps({'error': 'Cannot get destination folder UID'})
			else:
				cache.clear()
				return json.dumps({'error': 'Cannot get parent folder UID'})
		else:
			return cache.get('destFolderUid')

	else:
		cache.clear()
		return json.dumps(
				{'error': 'Error fetching the session UID. Please verify the username and password for Grovestream.'})


# Returns organization UID
def get_org_uid():
	return _org_id()


# Get information of the organisation
def get_organization_details():
	res = _get(_url('/api/organization/{o}?api_key={a}'.format(o=_org_id(), a=_api_key())))

	if res.status_code == requests.codes.ok:
		return json.dumps(res.json())
	else:
		return json.dumps({'error': 'Error retrieving organization information.'})


# Get all components from the destination folder
def get_components():
	if cache.get('components') is None:
		res = _get(_url(
				'/api/cr/comp/{d}/children?session={s}&org={o}'.format(d=_dest_folder_uid(), s=_session_uid(),
				                                                       o=_org_id())))

		if res.status_code == requests.codes.ok:
			return cache.get_or_set('components', json.dumps(res.json()['cr_node']['children']))
		else:
			cache.clear()
			return json.dumps({'error': 'Error fetching the list of components.', 'status_code': res.status_code})
	else:
		return cache.get('components')


# Get all streams for a component
def get_component_streams(component_uid):
	if cache.get("{c}_streams".format(c=component_uid)) is None:
		res = _get(_url('/api/component/{c}/stream?api_key={a}'.format(c=component_uid, a=_api_key())))

		if res.status_code == requests.codes.ok:
			return cache.get_or_set("{c}_streams".format(c=component_uid), json.dumps(res.json()))
		else:
			cache.clear()
			return json.dumps({'error': 'Error fetching the list of streams for componentUID: %s' % component_uid})
	else:
		cache.get("{c}_streams".format(c=component_uid))


# Get a particular stream for a component
def get_component_stream(component_uid, stream_uid):
	if cache.get("{c}_{s}_stream".format(c=component_uid, s=stream_uid)) is None:
		res = _get(
				_url('/api/component/{c}/stream/{s}?api_key={a}'.format(c=component_uid, s=stream_uid, a=_api_key())))

		if res.status_code == requests.codes.ok:
			return cache.get_or_set("{c}_{s}_stream".format(c=component_uid, s=stream_uid), json.dumps(res.json()))
		else:
			cache.clear()
			return json.dumps({'error': 'Error fetching the stream for UID: %s' % stream_uid})
	else:
		return cache.get("{c}_{s}_stream".format(c=component_uid, s=stream_uid))


# Get data related to a stream
def get_feed_data(component_uid, stream_uid):
	import time
	from datetime import datetime, timedelta

	# res = _get(_url(
	# 		'/api/feed?api_key={a}&org={o}&items={c}.{s}&startDate=0&endDate={'
	# 		'e}&intvlDates=return&requestTimeZoneId=UTC'.format(
	# 				a=_api_key(), o=_org_id(), c=component_uid, s=stream_uid, e=int(round(time.time() * 1000)))))

	startDat = int(((datetime.now() + timedelta(days=-90)).strftime('%s')))*1000
	res = _get(_url('/api/feed?api_key={a}&org={o}&items={c}.{s}&startDate={''f}&endDate={''e}&intvlDates=return&requestTimeZoneId=UTC'.format(a=_api_key(), o=_org_id(), c=component_uid, s=stream_uid, f=startDat, e=int(round(time.time() * 1000)))))

	if res.status_code == requests.codes.ok:
		return json.dumps(res.json())
	else:
		return json.dumps({'error': 'Error fetching feed data'})