from django.conf.urls import url
from guardian import admin
from django.contrib import admin
from . import views

urlpatterns = [

]