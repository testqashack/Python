from __future__ import unicode_literals
from django.contrib import admin
from .models import *
from dashboards.models import *
from groveapi.models import *
# from email_report.models import *

class ApiAdmin(admin.ModelAdmin):
	list_display = ('email',)

class CompStreamAdmin(admin.ModelAdmin):
	list_display = ('component', 'streams', 'email')
	list_filter = ['component']

	#Override the django page by using the jQuery
	class Media:
		js = (
			'//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js',
			'js/custom.js',
		)

@admin.register(ApiDetail)
class ApiDetailAdmin(admin.ModelAdmin):
	list_display = ('api_key','type','url','dest_folder')
	list_display_links = ('api_key',)

admin.site.register(CompStream,CompStreamAdmin)
# admin.site.register(CompStream)