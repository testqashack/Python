from django.conf.urls import url
from guardian import admin
from django.contrib import admin
from . import views

admin.autodiscover()

urlpatterns = [

	# Mailer Configuration add/edit views
	url(r'mailer_config/(?P<id>)$', views.MailerConfig, name='mailer.config'),

	# Display the values in the 'feed_details'
	url(r'feed_details/', views.feed, name='feed'),
	# url(r'mail/', views.send_mail, name='send_email'),

	#URL for 'edit' mail.config page
	url(r'^(?P<id>\d+)/mailer_config_edit/', views.updateInformation, name='mailer_config_edit'),

	# For Ajax call
	url(r'^component/validate_compid', views.streamsview, name='streamsview'),

	#Save the data to Database
	url(r'^save_details', views.save_details, name="save_details")
]
