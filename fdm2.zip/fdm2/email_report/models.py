from __future__ import unicode_literals
from dashboards.models import *
from groveapi.models import *

from django.db import models


# For Fetching the Email
class AuthUser(models.Model):
	password = models.CharField(max_length=128)
	last_login = models.DateTimeField(blank=True, null=True)
	is_superuser = models.BooleanField()
	username = models.CharField(unique=True, max_length=150)
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	email = models.CharField(max_length=254)
	is_staff = models.BooleanField()
	is_active = models.BooleanField()
	date_joined = models.DateTimeField()

	class Meta:
		managed = False
		db_table = 'auth_user'

# CompStream table for storing the CompStream values
# class CompStream(models.Model):
# 	component = models.CharField(max_length=128, unique=True)
# 	streams = models.CharField(max_length=128, unique=True)
# 	email = models.CharField(max_length=254)
#
# 	class Meta:
# 		ordering = ['component']
# 		verbose_name = 'CompStream Information'
# 		verbose_name_plural = 'CompStreams Information'
# 		db_table = 'CompStream'
