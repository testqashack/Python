from django import forms
from models import *
import re

# Form for display the list of component values
class ComponentListForm(forms.Form):
    val_list = ComponentDetail.objects.values_list('id','id')
    OPTIONSLIST = tuple(val_list)
    componentsList = forms.MultipleChoiceField(
		    choices=OPTIONSLIST,
            label='Select the Component',
            widget=forms.SelectMultiple,
    )

# Form for create a table to store the email_config values
class CompStreamForm(forms.Form):
    component = models.CharField(max_length=128, unique=True)
    streams = models.CharField(max_length=128, unique=True)
    email = models.CharField(max_length=254, unique=True)

# Form for Edit mail_config
class EditForm(forms.Form):
    component_list = ComponentDetail.objects.values_list('id', 'id')
    OPTIONSLIST1 = tuple(component_list)
    component = forms.MultipleChoiceField(
            choices=OPTIONSLIST1,
            widget=forms.SelectMultiple,
            required=True
    )

    email_list = AuthUser.objects.values_list('email', 'email')
    OPTIONSLIST2 = tuple(email_list)
    email = forms.MultipleChoiceField(
		    widget=forms.SelectMultiple,
            choices=OPTIONSLIST2,
            required=True,
    )

    # Multiple Choice fields
    def __init__(self, pk, *args, **kwargs):
        super(EditForm, self).__init__(*args, **kwargs)
        self.pk=pk
        instance = CompStream.objects.filter(id=self.pk)
        x=0

        for inst in instance:

            # Components
            self.initial['component'] = inst.component.split(",")

            componentArr = inst.component.split(",")
            streamsArr = inst.streams.split(",")

            # Streams
            for co in componentArr:
                print(co.replace(" ","-"))
                x=x+1

                self.fields['component-streams-select-%s' % co.replace(" ","-")] = StreamModelChoiceField(
                        queryset=StreamDetail.objects.filter(comp_id=co),
                        # queryset=StreamDetail.objects.all(),
                        widget=forms.SelectMultiple(attrs={'id': 'component-streams-select-%s' % co.replace(" ","-")}),
                        required=True
                )

                # self.fields['component-streams-select-%s' % co.replace(" ","-")].queryset = StreamDetail.objects.filter(comp_id=co)
                self.initial['component-streams-select-%s' % co.replace(" ","-")] = streamsArr

            #email
            self.initial['email'] = inst.email.split(",")


class StreamModelChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        print(obj.__getattribute__('name'))
        return obj.__getattribute__('name')