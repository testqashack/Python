from __future__ import print_function
from datetime import datetime, timedelta
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from models import *
import re
from django.contrib.auth.decorators import login_required
from django.core import serializers
from django.http import JsonResponse, HttpResponse
from django.forms import modelformset_factory
from django.shortcuts import render, redirect
from dashboards.models import *
from forms import *

@login_required
#view function for ComponentListForm
def MailerConfig(request, id):

	# Fetching all the components from 'ComponentListForm' and display it in component form
	componentListForm = ComponentListForm(request.POST)
	print (componentListForm)

	# Fetching all the Emails from the 'AuthUSer' table and display it in email form
	userList = AuthUser.objects.all()

	title = 'Create new Mailer Configuration'
	if (len(id) > 0):
		title = 'Edit Mailer Configuration'

	#Fetch all the information from 'CompStream' table and display
	emailList = CompStream(request.POST)
	emailList = CompStream.objects.all()


	return render(request, 'mailer_configuration.html', locals())


#view function for StreamForm which is autopopulating
@login_required
def streamsview(request):
	#Compare all the components in 'stream_details' tables in list it in streams forms
	compId = request.GET.get('comp_id', None)
	data = {
		'comp_info': serializers.serialize("json", StreamDetail.objects.filter(comp_id=compId))
	}
	return JsonResponse(data)

#view function for save the entered data into the 'CompStream' table
def save_details(request):
	qset = CompStream.objects.filter(id=request.POST.get('edit_id_val'))

	if qset.count() > 0:
		counter=0

		component = ','.join(request.POST.getlist('component'))
		streams = ''

		for key in request.POST:
			if re.match('component-streams-select-.*', key):
				for st in request.POST.getlist(key):
					if counter > 0:
						streams = streams + ',' + st
					else:
						streams = streams + st
					counter += 1

		email = ','.join(request.POST.getlist('email'))

		#update the form data into the tables
		qset.update(component=component, streams=streams, email=email)

		return redirect('/mailer_config')
	else:
		c_form = CompStreamForm(request.POST)

		if c_form.is_valid():

			# For multiple selection
			component = (",".join([component.encode("utf8") for component in request.POST.getlist('componentsList')]))
			streams = []

			for c in component.split(","):
				sId = c.replace(" ", "-")

				for s in request.POST.getlist('component-streams-select-'+sId):
					streams.append(s.encode("utf8"))

			streams = ",".join(streams)
			email = ''

			cntr = 0

			for key in request.POST:
				# print(key)

				# Select the multiple emails and save it to DB
				if re.match('email-[0-9]+', key):
					for em in request.POST.getlist(key):
						if cntr > 0:
							email = email + ',' + em
						else:
							email = email + em
						cntr += 1

			#Collect all the data fand save into the 'CompStream' table
			comp_obj = CompStream(component=component, streams=streams, email=email)
			comp_obj.save()

			#After save the data into 'CompStream' table redirect to main page[component_add']
			return redirect('/mailer_config')
		else:
			c_form = CompStreamForm()
		return render(request, 'mailer_configuration.html', {'c_form': c_form, })

#view function for edit_mailer_form
@login_required
def updateInformation(request, id=CompStream):
	edit_form = EditForm(id)
	context = {
		"title":"Edit Mailer Configuration",
		"form" : edit_form,
		'compstream_id': id,
	}
	return render(request, "mailer_configuration_edit.html", context)

# view function for calculating the average for 'feed_values'
@login_required
def feed(request, uid=FeedDetail.uid):
	uids = CompStream.objects.values_list('streams', 'email')
	stream_array = []
	generic_array = []

	for uid in uids:
		# Calculating the data for 1,7,15 and 21 days
		feed_s1 = FeedDetail.objects.filter(uid=uid[0]).filter(
			timestamp__gte=datetime.now() + timedelta(days=-1)).filter(timestamp__lte=datetime.now()).values_list('uid',
		                                                                                                          'value')
		feed_s7 = FeedDetail.objects.filter(uid=uid[0]).filter(
			timestamp__gte=datetime.now() + timedelta(days=-7)).filter(timestamp__lte=datetime.now()).values_list('uid',
		                                                                                                          'value')
		feed_s15 = FeedDetail.objects.filter(uid=uid[0]).filter(
			timestamp__gte=datetime.now() + timedelta(days=-15)).filter(timestamp__lte=datetime.now()).values_list(
			'uid', 'value')
		feed_s21 = FeedDetail.objects.filter(uid=uid[0]).filter(
			timestamp__gte=datetime.now() + timedelta(days=-21)).filter(timestamp__lte=datetime.now()).values_list(
			'uid', 'value')

		# Create a list for storing the values
		val_list_1 = []
		val_list_7 = []
		val_list_15 = []
		val_list_21 = []

		# Append the values to the empty lists
		for feeds in feed_s1:
			val_list_1.append(feeds[1])

		for feeds in feed_s7:
			val_list_7.append(feeds[1])

		for feeds in feed_s21:
			val_list_21.append(feeds[1])

		for feeds in feed_s15:
			val_list_15.append(feeds[1])

		# Calculating the Average values for the respective days
		if sum(val_list_1) > 0:
			val_1_Avg = (sum(val_list_1) / (len(val_list_1))) * 100
		else:
			val_1_Avg = 0

		if sum(val_list_7) > 0:
			val_7_Avg = (sum(val_list_7) / (len(val_list_7))) * 100
		else:
			val_7_Avg = 0

		if sum(val_list_15) > 0:
			val_15_Avg = (sum(val_list_15) / (len(val_list_15))) * 100
		else:
			val_15_Avg = 0

		if sum(val_list_21) > 0:
			val_21_Avg = (sum(val_list_21) / (len(val_list_21))) * 100
		else:
			val_21_Avg = 0

		stream_val = uid[0]

		# Append all the values to the main list
		generic_array.append({'stream': stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg,
		                      'val_1' : val_1_Avg})
		local_array = []
		local_array.append({'stream': stream_val, 'val_21': val_21_Avg, 'val_15': val_15_Avg, 'val_7': val_7_Avg,
		                    'val_1' : val_1_Avg})

		local_email_array = []
		email_ids_array = uid[1].split(',')

		for email in email_ids_array:
			local_email_array.append(email)

	# print("----------- Printing generic List-----------------------")
	# print(generic_array)
	return render(request, 'feed_details.html', locals(), {'generic_array': generic_array})

# HTML template for sending an email
def send_email(local_array, local_email_array):
	subject = 'Feed details information'
	mail_string = '''
			<html>
			<head>
				<title> Feeds details</title>
			</head>
			<body>
				<table border='1'>
					<tbody>
						<tr style="background-color: #4CAF50; color:#ffffff">
				            <th>Stream UID</th>
				            <th>Last 1 day data Average</th>
				            <th>Last 7 days data Average</th>
				            <th>Last 15 days data Average</th>
				            <th>Last 21 days data Average</th>
				        </tr>
			            <tr>
			                <td>''' + local_array[0]['stream'] + '''</td>
			                <td>''' + str(local_array[0]['val_1']) + '''</td>
			                <td>''' + str(local_array[0]['val_7']) + '''</td>
			                <td>''' + str(local_array[0]['val_15']) + '''</td>
			                <td>''' + str(local_array[0]['val_21']) + '''</td>
			            </tr>
					</tbody>
				</table>
				</body>
			</html>'''

	text_content = mail_string

	# Sending a HTML file as mail to the stored reciepients in the 'CompStream' table
	msg = EmailMultiAlternatives(subject, text_content, settings.EMAIL_HOST_USER, local_email_array)
	msg.attach_alternative(mail_string, "text/html")
	# msg.attach_alternative(mail_string, "application/pdf")
	msg.send()
