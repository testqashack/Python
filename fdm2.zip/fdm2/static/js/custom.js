// $(document).ready(function(){
//     // alert('Compstream details')
//     var urlVal =window.location.pathname;
//     console.log(urlVal)
//     if(urlVal.includes('compstream')){
//         $('#content .addlink').attr('href','/mailer_config/')
//     }
//
//
//     if(urlVal.includes('admin')){
//         console.log('Correct page')
//         $('.dashboard-module-content ul').each(function(){
//             if($(this).find('a').attr('href') == '/cp/admin/'){
//                 console.log("found")
//             }
//         })
//     }
// })



$(document).ready(function(){
    // alert('Compstream details')
    var urlVal =window.location.pathname;
    console.log(urlVal)
    if(urlVal.includes('compstream')){
        $('#content .addlink').attr('href','/mailer_config/')
    }


    if(urlVal.includes('cp')){
        console.log("Clled")
        $('.model-compstream .addlink').attr('href','/mailer_config/')
    }


    if(urlVal.includes('admin')){
        console.log('Correct page')
        $('model-compstream').each(function(){
            if($(this).find('a').attr('href') == '/cp/admin/'){
                console.log("found")
            }
        })
    }
})
